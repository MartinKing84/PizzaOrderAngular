export const settings = {
  size: [
    { id: 1, name: "Mała", price: 10 },
    { id: 2, name: "Średnia", price: 14 },
    { id: 3, name: "Duża", price: 18 }
  ],
  sauce: [
    { id: 1, name: "Bez", price: 0 },
    { id: 2, name: "Łagodny", price: 2 },
    { id: 3, name: "Pikantny", price: 2 }
  ],
  basicIngredients: [
    {
      id: 1,
      name: "sos pomidorowy",
      price: 2,
      selected: false
    },
    {
      id: 2,
      name: "cebula",
      price: 1,
      selected: false
    },
    {
      id: 3,
      name: "ser",
      price: 6,
      selected: false
    },
    {
      id: 4,
      name: "papryka",
      price: 8
    }
  ],
  additionalMeatIngredients: [
    {
      id: 1,
      name: "szynka",
      price: 12,
      selected: false
    },
    {
      id: 2,
      name: "salami",
      price: 14,
      selected: false
    },
    {
      id: 3,
      name: "kielbasa",
      price: 5
    }
  ],
  additionalVegeIngredients: [
    {
      id: 1,
      name: "oscypek",
      price: 20,
      selected: false
    },
    {
      id: 2,
      name: "ananas",
      price: 3,
      selected: false
    },
    {
      id: 3,
      name: "brokuł",
      price: 5,
      selected: false
    }
  ]
};
