import { Component } from "@angular/core";
import {
  FormGroup,
  FormArray,
  FormBuilder,
  Validators,
  FormControl
} from "@angular/forms";

import { settings } from "./settings";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent {
  public isErrorMsgVisible = false;
  public formGroup: FormGroup;

  public size: any[];
  public sauce: any[];
  public basicIngredients: any[];
  public additionalMeatIngredients: any[];
  public additionalVegeIngredients: any[];

  public sum: number = 0;

  constructor(private formBuilder: FormBuilder) {
    this.createForm();
    console.log("from constructor: ");

    this.size = settings.size;
    this.sauce = settings.sauce;
    this.basicIngredients = settings.basicIngredients;
    this.additionalMeatIngredients = settings.additionalMeatIngredients;
    this.additionalVegeIngredients = settings.additionalVegeIngredients;
  }

  private buildBasicIngredients() {
    const arr = settings.basicIngredients.map(ingredient => {
      return this.formBuilder.control(ingredient.selected);
    });
    return this.formBuilder.array(arr);
  }

  private buildMeatIngredients() {
    const arr = settings.additionalMeatIngredients.map(ingredient => {
      return this.formBuilder.control(ingredient.selected);
    });
    return this.formBuilder.array(arr);
  }

  private buildVegeIngredients() {
    const arr = settings.additionalVegeIngredients.map(ingredient => {
      return this.formBuilder.control(ingredient.selected);
    });
    return this.formBuilder.array(arr);
  }

  public onChangeMetaIngredients(event) {
    const pizzaMeatIngredient = this.formGroup.get(
      "pizzaMeatIngredient"
    ) as FormArray;

    if (event.checked) {
      pizzaMeatIngredient.push(new FormControl(event.source.value));
    } else {
      const i = pizzaMeatIngredient.controls.findIndex(
        x => x.value === event.source.value
      );
      pizzaMeatIngredient.removeAt(i);
    }
  }

  public onChangeVegeIngredients(event) {
    const pizzaVegeIngredient = this.formGroup.get(
      "pizzaVegeIngredient"
    ) as FormArray;

    if (event.checked) {
      pizzaVegeIngredient.push(new FormControl(event.source.value));
    } else {
      const i = pizzaVegeIngredient.controls.findIndex(
        x => x.value === event.source.value
      );
      pizzaVegeIngredient.removeAt(i);
    }
  }

  public onChangeBasicIngredients(event) {
    const pizzaBasicIngredient = this.formGroup.get(
      "pizzaBasicIngredient"
    ) as FormArray;

    if (event.checked) {
      pizzaBasicIngredient.push(new FormControl(event.source.value));
    } else {
      const i = pizzaBasicIngredient.controls.findIndex(
        x => x.value === event.source.value
      );
      pizzaBasicIngredient.removeAt(i);
    }
  }

  private calculate() {
    const rawValue = this.formGroup.getRawValue();

    const calcPizzaBasicIngredients = rawValue.pizzaBasicIngredient.reduce(
      (acc, item) => acc + item.price,
      0
    );

    const calcPizzaWegeIngredients = rawValue.pizzaVegeIngredient.reduce(
      (acc, item) => acc + item.price,
      0
    );

    const calcPizzaMeatIngredients = rawValue.pizzaMeatIngredient.reduce(
      (acc, item) => acc + item.price,
      0
    );

    const sum =
      rawValue.amount *
        (calcPizzaBasicIngredients +
          calcPizzaMeatIngredients +
          calcPizzaWegeIngredients) +
      rawValue.pizzaSize.price +
      rawValue.pizzaSauce.price;

    alert("Zamówienie będzie kosztowac: " + sum + " zł");
  }

  private createForm() {
    this.formGroup = this.formBuilder.group({
      amount: ["", [Validators.required]],
      pizzaBasicIngredient: this.formBuilder.array([]),
      pizzaMeatIngredient: this.formBuilder.array([]),
      pizzaVegeIngredient: this.formBuilder.array([]),
      pizzaSize: ["", [Validators.required]],
      pizzaSauce: ["", [Validators.required]],
      sum: [0]
    });
  }
}
